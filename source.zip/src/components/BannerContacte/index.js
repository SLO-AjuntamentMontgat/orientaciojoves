import BannerContacte from './BannerContacte';

export default BannerContacte;
