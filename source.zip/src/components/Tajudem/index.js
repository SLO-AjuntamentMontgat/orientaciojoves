import Tajudem from './Tajudem';

export default Tajudem;
